---
title: { { title } }
date: { { date } }
type: # 【必需】标签、分类和友情链接三个页面需要配置
updated: # 【可选】页面更新日期
comments: # 【可选】显示页面评论模块 (默认 true)
description: # 【可选】页面描述
keywords: # 【可选】页面关键字
top_img: # 【可选】页面顶部图片
mathjax: # 【可选】显示 Mathjax (当设置 Mathjax 的 per_page: false 时，才需要配置， 默认 false)
katex: # 【可选】显示 Katex (当设置 Katex 的 per_page: false 时，才需要配置， 默认 false)
aside: # 【可选】显示侧边栏 (默认 true)
aplayer: # 【可选】在需要的页面加载 APlayer 的 js 和 css，请参考文章下面的音乐 配置
highlight_shrink: # 【可选】配置代码框是否展开 (true/false) (默认为设置中 highlight_shrink 的配置)
random: # 【可选】配置友情链接是否随机排序（默认为 false)
---
